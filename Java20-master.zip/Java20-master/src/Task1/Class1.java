package Task1;

public class Class1<T,V,K>{
    private T type;
    private K key;
    private V value;

}
